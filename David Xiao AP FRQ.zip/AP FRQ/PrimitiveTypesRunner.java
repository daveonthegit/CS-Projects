public class PrimitiveTypesRunner {
   public static void main(String[] args) {
   PrimitiveTypes.stringLiterals();
   PrimitiveTypes.primitiveTypes();
   PrimitiveTypes.arithmeticOperators();
   PrimitiveTypes.compoundAssignmentOperators();
   PrimitiveTypes.castingVariables();
   }
}